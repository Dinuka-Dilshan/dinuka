import ExperienceCard from "@/components/base/ExperienceCard";
import Section from "@/components/base/Section";
import benFahimnia from "@/images/benFahimnia.png";
import chanceLab from "@/images/chanceandchoicelab.png";

const FreelanceExperience = () => {
  return (
    <Section
      title={"Freelance & Side Projects"}
      subtitle={"Personal builds and freelance work beyond my day job."}
    >
      <div className="flex gap-5 flex-col">
        <ExperienceCard
          image={benFahimnia}
          title={"Ben Fahimnia - Personal Portfolio Website"}
          description={`A clean, modern portfolio site built for Ben Fahimnia, showcasing
            his work.The site is fully responsive, optimized for speed, and
            styled with a minimalist design.`}
          technologies={["Next.js", "Tailwind", "shadcn/ui", "Amplify"]}
          demoLink={"https://www.benfahimnia.com/"}
        />
        <ExperienceCard
          image={chanceLab}
          title={" Chance and Choice Lab - Portfolio & Survey Platform"}
          description={
            "A two-part web experience for Chance and Choice Lab, including a public-facing portfolio site and a secure behavioral survey platform."
          }
          technologies={[
            "React.js",
            "Mui",
            "React Query",
            "AWS Lambda",
            "AWS CDK",
            "Dynamodb",
            "API Gateway",
          ]}
          demoLink={"https://www.chanceandchoicelab.com/"}
        />
      </div>
    </Section>
  );
};

export default FreelanceExperience;

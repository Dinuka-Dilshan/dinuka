import { PropsWithChildren } from "react";

type Props = PropsWithChildren<{
  title: string;
  subtitle: string;
}>;

const Section = ({ subtitle, title, children }: Props) => {
  return (
    <section className="pt-6 flex flex-col h-fit mt-14 w-full">
      <h6 className="text-3xl font-semibold ">{title}</h6>
      <h6 className="font-semibold text-gray-500 mb-7">{subtitle}</h6>
      {children}
    </section>
  );
};

export default Section;
